<?php
header("Access-Control-Allow-Origin: *"); //Permite acceso desde cualquier origen
header("Access-Control-Allow-Methods: PUT"); //Solo permite método PUT
header("Content-Type: application/json"); //Salida en JSON

include 'conexion.php';

//Si el metodo no es PUT informamos al usuario de que cambie el metodo
if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
    http_response_code(405);
    echo json_encode(["error" => "Método no permitido"]);
    exit;
}

//Si el metodo es PUT ejecutamos el codigo
else {
    //Obtener datos enviados en formato JSON
    $data = json_decode(file_get_contents("php://input"), true);

    //Guardar los datos en variables
    $id = $_GET["id"] ?? null;
    $pregunta = $data['pregunta'];
    $categoria = $data['categoria'];
    $op1 = $data['respuesta1'];
    $op2 = $data['respuesta2'];
    $op3 = $data['respuesta3'];
    $op4 = $data['respuesta4'];
    $respuesta = $data['respuesta_correcta'];

    //Armar y ejecutar la consulta de actualización
    $sql = "UPDATE preguntas SET 
            pregunta='$pregunta', 
            categoria='$categoria',
            respuesta1='$op1', 
            respuesta2='$op2', 
            respuesta3='$op3',
            respuesta4='$op4', 
            respuesta_correcta='$respuesta' 
            WHERE id_pregunta=$id";

    //Enviar respuesta según el resultado
    if($conn->query($sql) === TRUE) {
        echo json_encode(["mensaje" => "Pregunta actualizada"]);
    } else {
        echo json_encode(["error" => $conn->error]);
    }

    $conn->close();
}
?>
