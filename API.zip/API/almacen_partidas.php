<?php

header("Content-Type: application/json");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require 'conexion.php';

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Conexión fallida: " . $conn->connect_error]);
    exit();
}

// --- 4. Obtener los datos del cuerpo de la solicitud JSON ---
$json_data = file_get_contents("php://input");
$data = json_decode($json_data, true); // true para obtener un array asociativo

// --- 5. Validar los datos recibidos ---
if (empty($data) || !isset($data['puntuacion']) || !isset($data['dificultad']) || !isset($data['rondasJugadas'])) {
    http_response_code(400); // Bad Request
    echo json_encode(["success" => false, "message" => "Datos de partida incompletos."]);
    $conn->close();
    exit();
}

// Recopilar los datos
$puntuacion = (int)$data['puntuacion'];
$dificultad = $conn->real_escape_string($data['dificultad']); // Sanear string
$rondasJugadas = (int)$data['rondasJugadas'];
// Asumo que 'jugador_id' y 'resultado' podrían ser opcionales o tener valores por defecto
$resultado = isset($data['resultado']) ? $conn->real_escape_string($data['resultado']) : 'Finalizado';

// Generar la fecha actual del servidor (más seguro)
$fechaActual = date('Y-m-d H:i:s');

// --- 6. Preparar y ejecutar la consulta de inserción (usando sentencias preparadas) ---
// Asegúrate de que los nombres de las columnas coincidan con tu tabla 'partidas'
$sql = "INSERT INTO partidas (puntuacion, dificultad, rondas_jugadas, resultado, fecha) VALUES (?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

if ($stmt === false) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Error al preparar la consulta: " . $conn->error]);
    $conn->close();
    exit();
}

// "s" = string, "i" = integer
$stmt->bind_param("issss", $puntuacion, $dificultad, $rondasJugadas, $resultado, $fechaActual);

if ($stmt->execute()) {
    http_response_code(201); // Created
    echo json_encode(["success" => true, "message" => "Partida guardada correctamente.", "id" => $conn->insert_id]);
} else {
    http_response_code(500); // Internal Server Error
    echo json_encode(["success" => false, "message" => "Error al guardar la partida: " . $stmt->error]);
}

// --- 7. Cerrar la conexión ---
$stmt->close();
$conn->close();
?>