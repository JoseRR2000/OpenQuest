<?php
/*Datos requeridos para conectarme a la base de datos*/
$host = "localhost";
$db = "OpenQuest";
$user = "root";
$pass = "Pepeelrey1.";

/*Creo una conexion con mySQL con los datos anteriores*/
$conn = new mysqli($host, $user, $pass, $db);

/*Si hay error en la conexion se lo hago saber al usuario*/ 
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>
