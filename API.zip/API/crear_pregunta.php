<?php
header("Access-Control-Allow-Origin: *");   //Permite acceso desde cualquier origen
header("Access-Control-Allow-Methods: POST");   //Solo permite método POST
header("Content-Type: application/json");   //La salida será un JSON

/*El archivo dependerá del funcionamiento de la conexión a la BBDD*/
include 'conexion.php';


/*Si la peticion no es post, le haremos saber al usuario que cambie el metodo*/
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); // Método no permitido
    echo json_encode(["error" => "Método no permitido"]);
    exit;
}

/*Si es POST se ejecutara el codigo*/
else {
    /*Obtener datos enviados desde el body en formato JSON*/
    $data = json_decode(file_get_contents("php://input"), true);

    /*Guardo los datos en variables*/
    $pregunta = $data['pregunta'];
    $categoria = $data['categoria'];
    $op1 = $data['respuesta1'];
    $op2 = $data['respuesta2'];
    $op3 = $data['respuesta3'];
    $op4 = $data['respuesta4'];
    $respuesta = $data['respuesta_correcta'];

    /*Inserta en la tabla preguntas los datos*/
    $sql = "INSERT INTO preguntas (pregunta, categoria, respuesta1, respuesta2, respuesta3, respuesta4, respuesta_correcta) 
            VALUES ('$pregunta', '$categoria','$op1', '$op2', '$op3', '$op4', '$respuesta')";

    /*Enviar respuesta según si se insertó correctamente*/
    if($conn->query($sql) === TRUE) {
        echo json_encode(["mensaje" => "Pregunta creada"]);
    } else {
        echo json_encode(["error" => $conn->error]);
    }

    $conn->close();   
}
?>
