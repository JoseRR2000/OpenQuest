<?php
header("Access-Control-Allow-Origin: *");   //Permite acceso desde cualquier origen
header("Access-Control-Allow-Methods: DELETE"); //Solo permite método DELETE
header("Content-Type: application/json");   //Salida en JSON

//El funcionamiento del archivo dependerá de la conexion a la BBDD
include 'conexion.php';

//Si el metodo no es DELETE informaremos al usuario que cambie el metodo
if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    http_response_code(405); // Método no permitido
    echo json_encode(["error" => "Método no permitido"]);
    exit;

//Si el metodo es DELETE ejecutaremos el codigo
} else {
    // Obtener ID desde la URL (GET)
    $id = $_GET['id_pregunta'];

    // Ejecutar consulta para eliminar la pregunta
    $sql = "DELETE FROM preguntas WHERE id_pregunta = $id";

    // Enviar respuesta según el resultado
    if($conn->query($sql) === TRUE) {
        echo json_encode(["mensaje" => "Pregunta eliminada"]);
    } else {
        echo json_encode(["error" => $conn->error]);
    }

    $conn->close();
}
?>
