<?php
// login.php

header('Content-Type: application/json'); // Indica que la respuesta será JSON

// Incluir tu archivo de conexión a la base de datos
// Asegúrate de que esta ruta sea correcta para tu entorno de servidor
include 'conexion.php';

// Verificar que la solicitud sea de tipo POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método de solicitud no permitido.']);
    exit();
}

// Obtener los datos enviados por la aplicación Android (desde @Field de Retrofit)
// Los nombres de las claves aquí ('username', 'password') deben coincidir con los @Field en Android
$username = $_POST['username'] ?? ''; // Puede ser un nombre de usuario o un email
$password = $_POST['password'] ?? '';

// Validar que se recibieron los datos (comprobación básica de campos vacíos)
if (empty($username) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Usuario y contraseña son obligatorios.']);
    exit();
}

// Verificar si la conexión a la base de datos fue exitosa
if (!$conn) {
    // Si getDbConnection devuelve null (o hay un error de conexión)
    echo json_encode(['success' => false, 'message' => 'Error de conexión a la base de datos.']);
    exit();
}

try {
    // Preparar la consulta SQL para buscar el usuario.
    // Busca tanto por 'nombre' (username) como por 'email' en la tabla 'jugadores'.
    // Esto es útil si permites iniciar sesión con cualquiera de los dos.
    $stmt = $conn->prepare("SELECT id_jugador, nombre, email, contraseña FROM jugadores WHERE nombre = ? OR email = ?");

    // Verificar si la preparación de la consulta fue exitosa
    if ($stmt === false) {
        throw new Exception("Error al preparar la consulta: " . $conn->error);
    }

    // Vincular los parámetros. 'ss' indica que ambos parámetros son strings.
    $stmt->bind_param("ss", $username, $username); // Se usa $username dos veces para buscar en ambas columnas

    // Ejecutar la consulta
    $stmt->execute();

    // Obtener el resultado de la consulta
    $result = $stmt->get_result();

    // Comprobar si se encontró exactamente un usuario
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc(); // Obtener los datos del usuario

        // Verificar la contraseña hasheada
        // ¡IMPORTANTE! 'contraseña' debe ser el nombre de la columna en tu tabla 'jugadores'
        // Asegúrate de que las contraseñas en tu DB estén hasheadas con password_hash()
        if ($password === $user['contraseña']) {
            // Login exitoso
            echo json_encode([
                'success' => true,
                'message' => 'Login exitoso.',
                'user_id' => $user['id_jugador'] // Devolver el ID del jugador
            ]);
        } else {
            // Contraseña incorrecta
            echo json_encode(['success' => false, 'message' => 'Credenciales incorrectas.']);
        }
    } else {
        // Usuario no encontrado o múltiples usuarios (lo cual no debería pasar con username/email únicos)
        echo json_encode(['success' => false, 'message' => 'Credenciales incorrectas.']);
    }

    // Cerrar el statement
    $stmt->close();
    // Cerrar la conexión a la base de datos
    $conn->close();

} catch (Exception $e) {
    // Capturar cualquier excepción que ocurra durante el proceso
    echo json_encode(['success' => false, 'message' => 'Error en el servidor: ' . $e->getMessage()]);
    // Registrar el error para depuración en el servidor (no visible para el usuario)
    error_log("Error en login.php: " . $e->getMessage());
    // Cerrar la conexión si está abierta
    if ($conn) {
        $conn->close();
    }
}
?>