<?php
header('Content-Type: application/json');

include 'conexion.php';

// Consulta para obtener logros
$sql = "SELECT nombre, descripcion FROM logros";
$resultado = $conn->query($sql);

$logros = [];

if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        $logros[] = $fila;
    }
    echo json_encode($logros);
} else {
    echo json_encode([]);
}

$conn->close();
?>
