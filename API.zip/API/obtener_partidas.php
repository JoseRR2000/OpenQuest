<?php
// --- 1. Establecer cabeceras para la API ---
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *"); // Permite solicitudes desde cualquier origen (ajusta en producción)
header("Access-Control-Allow-Methods: GET, OPTIONS"); // Permitir GET y OPTIONS
header("Access-Control-Allow-Headers: Content-Type, Authorization"); // Permitir cabeceras necesarias

// Manejar la solicitud OPTIONS (pre-flight request de CORS)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// --- 2. Conexión a la base de datos ---
// Asegúrate de que 'conexion.php' establece la variable $conn
require 'conexion.php';

if ($conn->connect_error) {
    http_response_code(500); // Internal Server Error
    echo json_encode(["success" => false, "message" => "Error de conexión a la base de datos: " . $conn->connect_error]);
    exit(); // Detener la ejecución si hay error de conexión
}

// --- 3. Consulta de partidas ordenada por puntuación ---
// ¡Importante! Selecciona TODOS los campos que necesitas en Android
// Asegúrate de que los nombres de las columnas coincidan con tu base de datos
$sql = "SELECT    
            resultado,       
            puntuacion,      
            dificultad,      
            rondas_jugadas AS rondasJugadas, 
            fecha            
        FROM partidas 
        ORDER BY puntuacion DESC";

$result = $conn->query($sql);

$partidas = [];

if ($result) { // Verificar si la consulta fue exitosa
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Convertir la fecha a timestamp en milisegundos
            // Esto es crucial para que Gson la mapee correctamente a java.util.Date
            $row['fecha'] = (new DateTime($row['fecha']))->getTimestamp() * 1000;

            // Asegurar que los tipos de datos sean correctos para JSON y Android
            // PHP a veces devuelve números como strings, forzamos el tipo
            $row['puntuacion'] = (int)$row['puntuacion'];
            $row['rondasJugadas'] = (int)$row['rondasJugadas'];

            $partidas[] = $row;
        }
    }
    // Si no hay filas, $partidas seguirá siendo un array vacío [], lo cual es correcto.
} else {
    // Si la consulta SQL falló por alguna razón
    http_response_code(500); // Internal Server Error
    echo json_encode(["success" => false, "message" => "Error en la consulta SQL: " . $conn->error]);
    $conn->close();
    exit();
}

// --- 4. Devolver la respuesta JSON ---
echo json_encode($partidas);

// --- 5. Cerrar la conexión a la base de datos ---
$conn->close();
?>