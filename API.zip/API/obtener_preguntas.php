<?php
/*Permito acceso desde cualquier origen y la respuesta será un JSON*/
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

/*Este archivo dependerá del funcionamiento de la conexion a la BBDD*/
include 'conexion.php';

/*Obtengo todas las preguntas con una query SQL*/
$sql = "SELECT * FROM preguntas";
$result = $conn->query($sql);

$preguntas = array();   //En este array se guardarán las preguntas

/*Recorremos cada fila del resultado y la agregamos al array*/
while($row = $result->fetch_assoc()) {
    $preguntas[] = $row;
}

/*La salida será un array en formato JSON*/
echo json_encode($preguntas);

/*Cerramos la conexión con la BBDD*/
$conn->close();
?>
