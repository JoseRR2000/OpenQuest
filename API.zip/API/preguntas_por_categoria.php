<?php
header("Content-Type: application/json");

require 'conexion.php';

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Error de conexión"]);
    exit;
}

$categoria = isset($_GET['categoria']) ? intval($_GET['categoria']) : 0;

if ($categoria <= 0) {
    http_response_code(400);
    echo json_encode(["error" => "Categoría inválida"]);
    exit;
}

$sql = "SELECT idPregunta, pregunta, categoria, respuesta1, respuesta2, respuesta3, respuesta4 , respuestaCorrecta FROM preguntas WHERE categoria = $categoria";
$result = $conn->query($sql);

$preguntas = [];

while ($row = $result->fetch_assoc()) {
    $preguntas[] = [
        "idPregunta"        => (int) $row['idPregunta'],
        "pregunta"  => $row['pregunta'],
        "respuesta1"   => $row['respuesta1'],
        "respuesta2"   => $row['respuesta2'],
        "respuesta3"   => $row['respuesta3'],
        "respuesta4"   => $row['respuesta4'],
        "respuestaCorrecta"  => $row['respuestaCorrecta']
    ];
}

echo json_encode($preguntas);
$conn->close();

?>
