<?php
// register.php

header('Content-Type: application/json');

include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método no permitido.']);
    exit();
}

$username = $_POST['username'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

if (empty($username) || empty($email) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Todos los campos son obligatorios.']);
    exit();
}

// Validaciones adicionales (puedes añadir más)
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Formato de email inválido.']);
    exit();
}

if (strlen($password) < 6) {
    echo json_encode(['success' => false, 'message' => 'La contraseña debe tener al menos 6 caracteres.']);
    exit();
}

if (!$conn) {
    echo json_encode(['success' => false, 'message' => 'Error de conexión a la base de datos.']);
    exit();
}

try {
    // Verificar si el nombre de usuario o email ya existen
    $stmt_check = $conn->prepare("SELECT id_jugador FROM jugadores WHERE nombre = ? OR email = ?");
    $stmt_check->bind_param("ss", $username, $email);
    $stmt_check->execute();
    $stmt_check->store_result();

    if ($stmt_check->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => 'El nombre de usuario o el email ya están registrados.']);
        $stmt_check->close();
        $conn->close();
        exit();
    }
    $stmt_check->close();

    // Insertar el nuevo usuario en la base de datos
    $stmt_insert = $conn->prepare("INSERT INTO jugadores (nombre, email, contraseña) VALUES (?, ?, ?)");
    $stmt_insert->bind_param("sss", $username, $email, $password);

    if ($stmt_insert->execute()) {
        echo json_encode(['success' => true, 'message' => 'Usuario registrado exitosamente.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error al registrar el usuario.']);
    }

    $stmt_insert->close();
    $conn->close();

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error en el servidor: ' . $e->getMessage()]);
    error_log("Error en register.php: " . $e->getMessage());
}
?>