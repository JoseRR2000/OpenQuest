DROP DATABASE IF EXISTS OpenQuest;
CREATE DATABASE OpenQuest;
USE OpenQuest;

/********************************************************************
***************************TABLAS************************************
********************************************************************/

-- TABLA DE JUGADORES LOGEADOS
CREATE TABLE jugadores(
	id_jugador INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100),
    email VARCHAR(100),
    contraseña VARCHAR(200) 
);

-- TABLA DE PARTIDAS JUGADAS POR JUGADOR
CREATE TABLE partidas(
	id_partida INT PRIMARY KEY AUTO_INCREMENT,
    puntuacion INT,
    dificultad VARCHAR(100),
    rondas_jugadas INT,
    resultado VARCHAR(100),
    fecha DATETIME
);

-- TABLA DE LOGROS EXISTENTES EN EL JUEGO
CREATE TABLE logros(
	id_logro INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(200),
    descripcion VARCHAR(100)
);

-- TABLA DE CATEGORIAS EXISTENTES EN EL JUEGO
CREATE TABLE categorias(
	id_categoria INT PRIMARY KEY AUTO_INCREMENT,
    categoria VARCHAR(50)
);

-- TABLA DE PREGUNTAS EXISTENTES EN EL JUEGO
CREATE TABLE preguntas(
	idPregunta INT PRIMARY KEY AUTO_INCREMENT,
    pregunta VARCHAR(200),
    categoria INT,
    respuesta1 VARCHAR(100),
	respuesta2 VARCHAR(100),
    respuesta3 VARCHAR(100),
    respuesta4 VARCHAR(100),
	respuestaCorrecta VARCHAR(100),
    FOREIGN KEY (categoria) REFERENCES categorias(id_categoria)
);

/********************************************************************
***************TABLAS GENERADAS POR RELACIONES N-M*******************
********************************************************************/

-- TABLA DE LOGROS QUE HA COMPLETADO DE USUARIO
CREATE TABLE logros_usuario(
	id_logro INT,
    id_jugador INT,
    fecha DATETIME,
    completado BOOLEAN,
    PRIMARY KEY(id_logro, id_jugador),
    FOREIGN KEY (id_logro) REFERENCES logros(id_logro),
    FOREIGN KEY (id_jugador) REFERENCES jugadores(id_jugador)
);

-- TABLA DE PREGUNTAS HAN SALIDO EN CADA PARTIDA
CREATE TABLE preguntas_por_partida(
	idPregunta INT,
    id_partida INT,
    orden_aparicion INT,
    respondida_correctamente BOOLEAN,
    PRIMARY KEY (idPregunta, id_partida),
    FOREIGN KEY (idPregunta) REFERENCES preguntas(idPregunta),
    FOREIGN KEY (id_partida) REFERENCES partidas(id_partida)
);

/********************************************************************
********************INSERTS DE DATOS POR DEFECTO*********************
********************************************************************/

INSERT INTO categorias(categoria) VALUES
	("Geografía"),
    ("Historia"),
    ("Entretenimiento"),
    ("Deportes"),
    ("Informática"),
    ("Medicina");

INSERT INTO preguntas(pregunta, categoria, respuesta1, respuesta2, respuesta3, respuesta4, respuestaCorrecta) VALUES
	("¿Cuál es la capital de España?", 1, "Barcelona", "Madrid", "Valencia", "Málaga", "Madrid"),
    ("¿Cuál es el río más largo del mundo?", 1, "Nilo", "Amazonas", "Yangtsé", "Misisipi", "Amazonas"),
	("¿En qué continente se encuentra Mongolia?", 1, "Europa", "Asia", "África", "Oceanía", "Asia"),
	("¿Cuál es la montaña más alta del mundo?", 1, "K2", "Annapurna", "Everest", "Makalu", "Everest"),
	("¿Qué país tiene más islas en su territorio?", 1, "Canadá", "Suecia", "Indonesia", "Filipinas", "Suecia"),
	("¿Cuál es el país más pequeño del mundo?", 1, "Mónaco", "San Marino", "Malta", "Ciudad del Vaticano", "Ciudad del Vaticano"),
	("¿Qué océano baña la costa este de Estados Unidos?", 1, "Atlántico", "Pacífico", "Ártico", "Índico", "Atlántico"),
	("¿Qué desierto es el más grande del mundo?", 1, "Sáhara", "Gobi", "Antártico", "Kalahari", "Antártico"),
	("¿Cuál es la capital de Australia?", 1, "Sídney", "Melbourne", "Canberra", "Brisbane", "Canberra"),
	("¿Qué país tiene forma de bota?", 1, "España", "Grecia", "Italia", "Portugal", "Italia"),
	("¿Dónde se encuentran las cataratas del Iguazú?", 1, "Brasil y Perú", "Brasil y Argentina", "Argentina y Chile", "Uruguay y Brasil", "Brasil y Argentina"),
    ("¿En qué año comenzó la Segunda Guerra Mundial?", 2, "1937", "1939", "1941", "1945", "1939"),
	("¿Quién fue el primer emperador romano?", 2, "Julio César", "Augusto", "Nerón", "Tiberio", "Augusto"),
	("¿Cuál fue la causa principal de la Revolución Francesa?", 2, "El hambre", "La desigualdad social", "La invasión extranjera", "El absolutismo ruso", "La desigualdad social"),
	("¿En qué año cayó el Imperio Romano de Occidente?", 2, "395", "410", "476", "500", "476"),
	("¿Quién descubrió América?", 2, "Cristóbal Colón", "Américo Vespucio", "Leif Erikson", "Hernán Cortés", "Cristóbal Colón"),
	("¿Qué civilización construyó las pirámides de Egipto?", 2, "Sumerios", "Griegos", "Egipcios", "Mayas", "Egipcios"),
	("¿Qué muro cayó en 1989 simbolizando el fin de la Guerra Fría?", 2, "Muro de Berlín", "Muro de Adriano", "Muro de los Lamentos", "Muro de Maginot", "Muro de Berlín"),
	("¿Quién lideró la independencia de la India en el siglo XX?", 2, "Jawaharlal Nehru", "Subhas Chandra Bose", "Mahatma Gandhi", "Indira Gandhi", "Mahatma Gandhi"),
	("¿Dónde tuvo lugar la Revolución Industrial?", 2, "Francia", "Estados Unidos", "Alemania", "Reino Unido", "Reino Unido"),
	("¿Cuál fue la principal causa de la Primera Guerra Mundial?", 2, "La invasión de Polonia", "El asesinato del archiduque Francisco Fernando", "El ataque a Pearl Harbor", "La Guerra Civil Española", "El asesinato del archiduque Francisco Fernando");
    
	INSERT INTO logros(nombre, descripcion) VALUES
    ("EN RACHA", "Has acertado tres preguntas seguidas"),
    ("INFALIBLE", "Has acertado diez preguntas seguidas");
    
    SELECT * FROM preguntas;
    SELECT * FROM logros;
    SELECT * FROM partidas;
    SELECT * FROM jugadores;